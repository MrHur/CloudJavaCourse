package mit.gumin.center.utils;

public class InitSampleData {
	
	private String[] mIds;
	private String[] mPws;
    private String[] mNames;
    private String[] mPhones;
    private String[] mMails;
	/*
	 * private String[] newDates; private String[] changeDates;
	 */
    
	public String[] getmIds() {
		return mIds;
	}
	public void setmIds(String[] mIds) {
		this.mIds = mIds;
	}
	public String[] getmPws() {
		return mPws;
	}
	public void setmPws(String[] mPws) {
		this.mPws = mPws;
	}
	public String[] getmNames() {
		return mNames;
	}
	public void setmNames(String[] mNames) {
		this.mNames = mNames;
	}
	public String[] getmPhones() {
		return mPhones;
	}
	public void setmPhones(String[] mPhones) {
		this.mPhones = mPhones;
	}
	public String[] getmMails() {
		return mMails;
	}
	public void setmMails(String[] mMails) {
		this.mMails = mMails;
	}
	/*
	 * public String[] getNewDates() { return newDates; } public void
	 * setNewDates(String[] newDates) { this.newDates = newDates; } public String[]
	 * getChangeDates() { return changeDates; } public void setChangeDates(String[]
	 * changeDates) { this.changeDates = changeDates; }
	 */
	
    
    
    
}
