$(document).ready(function() {
  // 상품 데이터 (예시)
  const products = [
      {
          name: '럭셔리 주얼리 1',
          description: '고급 주얼리 설명 1',
          price: 1500000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 주얼리 2',
          description: '고급 주얼리 설명 2',
          price: 2200000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 주얼리 3',
          description: '고급 주얼리 설명 3',
          price: 3800000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 주얼리 4',
          description: '고급 주얼리 설명 4',
          price: 4500000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 핸드백 1',
          description: '고급 핸드백 설명 1',
          price: 5200000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 시계 1',
          description: '고급 시계 설명 1',
          price: 6800000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 액세서리 1',
          description: '고급 액세서리 설명 1',
          price: 1200000,
          imageUrl: 'https://via.placeholder.com/300x300'
      },
      {
          name: '럭셔리 주얼리 5',
          description: '고급 주얼리 설명 5',
          price: 3500000,
          imageUrl: 'https://via.placeholder.com/300x300'
      }
  ];

    // 상품 카드 생성 및 추가
    const productGrid = $('.luxury-product-grid');
    products.forEach(product => {
        const card = createProductCard(product);
        productGrid.append(card);
    });

    // 상품 카드 생성 함수 (수정)
    function createProductCard(product) {
        const card = $(`
            <div class="luxury-product-card">
                <img src="${product.imageUrl}" class="card-img-top" alt="${product.name}">
                <div class="card-body">
                    <h5 class="card-title">${product.name}</h5>
                    <p class="card-text">${product.description}</p>
                    <p class="price">${product.price.toLocaleString()}원</p>
                    <a href="#" class="btn btn-dark">구입 문의하기</a>
                </div>
            </div>
        `);
        return card;
    }
});