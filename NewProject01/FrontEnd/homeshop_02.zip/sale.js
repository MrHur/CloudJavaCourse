$(document).ready(function() {
  let currentPage = 1;
  const pageSize = 8; // 한 페이지에 보여줄 상품 개수

  // 더보기 버튼 클릭 이벤트 핸들러
  $('#load-more-btn').click(function() {
      loadProducts(currentPage, pageSize);
      currentPage++;
  });

  // 초기 상품 로드
  loadProducts(currentPage, pageSize);

  // 상품 로드 함수
  function loadProducts(page, size) {
      // 서버에서 상품 데이터 받아오기 (예시)
      const products = [
          {
              name: '제품 1',
              description: '제품 설명 1',
              originalPrice: 99000,
              salePrice: 79000,
              imageUrl: 'https://via.placeholder.com/300x200'
          },
          // 더 많은 상품 데이터 추가
      ];

      const startIndex = (page - 1) * size;
      const endIndex = startIndex + size;
      const productsToShow = products.slice(startIndex, endIndex);

      // 상품 카드 생성 및 추가
      const productGrid = $('.row');
      productsToShow.forEach(product => {
          const card = createProductCard(product);
          productGrid.append(card);
      });
  }
})
  