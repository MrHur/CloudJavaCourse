// 캐러셀 자동 슬라이드 기능
$('.carousel').carousel({
  interval: 5000, // 5초마다 자동 슬라이드
  pause: 'hover' // 마우스 오버 시 일시 정지
});